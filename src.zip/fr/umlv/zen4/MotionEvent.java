package fr.umlv.zen4;

/**
 * Event corresponding to a motion of the pointer on the screen.
 * 
 * @see ApplicationContext#pollMotionTracker()
 * @see ApplicationContext#waitAndBlockUntilAMotion()
 */
public class MotionEvent {
  private final Action action;
  private final float x;
  private final float y;
  
  /**
   * Action of the pointer on the screen.
   */
  public enum Action {
    DOWN, UP, MOVE
  }
  
  MotionEvent(Action action, float x, float y) {
    this.action = action;
    this.x = x;
    this.y = y;
  }
  
  /**
   * Returns the action of the current event.
   * @return the action of the current event.
   */
  public Action getAction() {
    return action;
  }
  
  /**
   * Returns the x coordinate of the pointer on the screen.
   * @return the x coordinate of the pointer on the screen.
   */
  public float getX() {
    return x;
  }
  
  /**
   * Returns the y coordinate of the pointer on the screen.
   * @return the y coordinate of the pointer on the screen.
   */
  public float getY() {
    return y;
  }
  
  @Override
  public String toString() {
    return action + " (" + x + ',' + y  + ')'; 
  }
}
