package fr.umlv.zen4;

import java.awt.Graphics2D;

/**
 * Called by {@link ApplicationContext#renderFrame(GraphicsConsumer)}
 * in order to render one frame of the game.
 * The method {@link #accept(Graphics2D, boolean)} can be called more
 * than once if content of the screen is lost while rendering.
 */
@FunctionalInterface
public interface GraphicsConsumer {
  /**
   * Code that render a frame of the game.
   * @param graphics2d a Graphics2D object able to draw on the
   *                   current screen.
   * @param contentLost true if the content of the screen is lost
   *                    thus a full refresh is needed.
   */
  public void accept(Graphics2D graphics2d, boolean contentLost);
}
