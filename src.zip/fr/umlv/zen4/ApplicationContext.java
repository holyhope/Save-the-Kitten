package fr.umlv.zen4;

/**
 * Provided by the application framework, this object allows
 * to {@link #renderFrame(GraphicsConsumer) render} a graphic code into
 * the drawing area of the application and
 * to {@link #waitAndBlockUntilAMotion() wait}/{@link #pollMotionTracker() ask}
 * for a motion event.
 */
public interface ApplicationContext {
  /**
   * Returns screen information.
   * @return screen information.
   * @throws IllegalStateException if this method is not called by the application thread.
   */
  public ScreenInfo getScreenInfo();
  
  /**
   * Exit the application.
   * @param exitStatus the exit status. By convention, a nonzero status code
    *                  indicates abnormal termination.
   * @throws IllegalStateException if this method is not called by the application thread.
   */
  public void exit(int exitStatus);
  
  /** 
   * Returns the first motion event since or the application was
   * started or {@link #pollMotionTracker()} or {@link #waitAndBlockUntilAMotion()},
   * was called or null if no motion happens.
   *  
   * @return a keyboard pressed event or null otherwise.
   * @throws IllegalStateException if this method is not called by the application thread.
   */
  public MotionEvent pollMotionTracker();
  
  /** 
   * Wait and block until either a motion event happen.
   *  
   * @return a motion event
   * @throws IllegalStateException if this method is not called by the application thread.
   * @throws InterruptedException if the application thread is interrupted when blocking.
   */
  public MotionEvent waitAndBlockUntilAMotion() throws InterruptedException;
  
  /**
   * Render the whole frame of the game in one call.
   * 
   * Because this method try to use the hardware acceleration, the content of the screen
   * is stored in the graphic card VRAM and may disappear at any moment.
   * If the content of the screen is lost the parameter {@code contentLost}
   * of the consumer taken as argument will be true. 
   * 
   * @param consumer a consumer that will be called {@code perhaps several times} to
   *                 render the current frame. 
   * @throws IllegalStateException if this method is not called by the application thread.                
   * @see GraphicsConsumer#accept(java.awt.Graphics2D, boolean)
   */
  public void renderFrame(GraphicsConsumer consumer);
}